class Color:
    white       = "#FFFFFF"
    whitegray   = "#EAEAEA"
    lightgray   = "#C2BFBF"
    middlegray  = "#AAAAAA"
    gray        = "#8C8C8C"
    darkgray    = "#3C4048"
    lightblue   = "#9ADBDE"
    blue        = "#00ABB3"
    red         = "#BC0000"
    